package com.ReviewSystem.review.DTO;

import java.time.LocalDateTime;

public class ReviewDTO {
    private String content;

    private Long likes;

    private Long productId;

    private Long userId;

    private LocalDateTime createdAt;

    private int status;

    public ReviewDTO() {

    }

    public ReviewDTO(String content, Long likes, Long productId, Long userId, LocalDateTime createdAt, int status) {
        this.content = content;
        this.likes = likes;
        this.productId = productId;
        this.userId = userId;
        this.createdAt = createdAt;
        this.status = status;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Long getLikes() {
        return likes;
    }

    public void setLikes(Long likes) {
        this.likes = likes;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
