package com.ReviewSystem.review.Controller;

import com.ReviewSystem.review.Model.Review;
import com.ReviewSystem.review.ReviewApplication;
import com.ReviewSystem.review.Service.ReviewService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/review")
public class ReviewController {

    private ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping("/test")
    public String sample() {
        return "Test API";
    }

    @GetMapping("/getAllReviews")
    public ResponseEntity<List<Review>> getAllReviews(@RequestParam(required = false) Long productId, @RequestParam(required = false) Integer offset, @RequestParam(required = false) Integer limit) {
        return ResponseEntity.ok(reviewService.getAllReviews(productId, offset, limit));
    }

    @PostMapping("/createReview")
    public ResponseEntity<Review> createReview(@RequestBody Review review) {
        return ResponseEntity.ok(reviewService.createReview(review));
    }






}
