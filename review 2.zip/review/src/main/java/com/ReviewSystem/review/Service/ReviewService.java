package com.ReviewSystem.review.Service;

import com.ReviewSystem.review.DTO.ReviewDTO;
import com.ReviewSystem.review.Model.Review;
import com.ReviewSystem.review.Repository.ReviewRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;

    public ReviewService(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    public List<Review> getAllReviews(Long productId, Integer offset, Integer limit) {

        if(offset == null || limit == null) {
            offset = 0;
            limit = 10;
        }
        Pageable pageable = PageRequest.of(offset, limit);

        Page<Review> page = reviewRepository.getReviewsByProductId(productId, pageable);

        return page.getContent();
    }

    public Review createReview(Review review) {
        return reviewRepository.save(review);
    }
}
